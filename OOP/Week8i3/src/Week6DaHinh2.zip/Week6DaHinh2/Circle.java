import java.util.Objects;

public class Circle extends Shape {
    protected double radius;
    protected Point center;

    /**
     * NTKong.
     */
    public Circle() {
    }

    /**
     * NTKong.
     */
    public Circle(double radius) {
        super();
        this.setRadius(radius);
    }

    /**
     * NTKong.
     */
    public Circle(double radius, String color, boolean filled) {
        super(color, filled);
        setRadius(radius);
    }

    /**
     * NTKong.
     */
    public Circle(Point point, double radius, String color, boolean filled) {
        super(color, filled);
        this.setRadius(radius);
        this.setCenter(point);
    }

    public Point getCenter() {
        return center;
    }

    public void setCenter(Point point) {
        this.center = point;
    }

    public double getRadius() {
        return radius;
    }

    public void setRadius(double radius) {
        this.radius = radius;
    }

    @Override
    public double getArea() {
        return Math.PI * getRadius() * getRadius();
    }

    @Override
    public double getPerimeter() {
        return 2.0 * Math.PI * getRadius();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Circle)) {
            return false;
        }
        Circle circle = (Circle) o;
        return Double.compare(circle.radius, radius) == 0
                && Objects.equals(center, circle.center);
    }

    @Override
    public int hashCode() {
        return Objects.hash(radius, center);
    }

    @Override
    public String toString() {
        String format = "Circle[center=%s,radius=%s,color=%s,filled=%s]";
        return String.format(format, getCenter(), getRadius(), getColor(), isFilled());
    }
}
