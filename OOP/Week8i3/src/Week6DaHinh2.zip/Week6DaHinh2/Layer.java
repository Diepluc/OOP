import java.util.ArrayList;
import java.util.List;

public class Layer {
    private final List<Shape> shapes;

    /**
     * NTKONG.
     */
    public Layer() {
        shapes = new ArrayList<>();
    }

    /**
     * NTKONG.
     */
    public void addShape(Shape shape) {
        shapes.add(shape);
    }

    /**
     * NTKONG.
     */
    public void removeCircles() {
        int i = shapes.size();
        while (i-- > 0) {
            Shape shape = shapes.get(i);
            if (shape instanceof Circle) {
                shapes.remove(shape);
            }
        }
    }

    /**
     * NTKONG.
     */
    public String getInfo() {
        String shapesInfo = "";
        for (Shape shape : shapes) {
            shapesInfo = shapesInfo.concat(shape.toString().concat("\n"));
        }
        return "Layer of crazy shapes:\n" + shapesInfo;
    }

    /**
     * NTKONG.
     */
    public void removeDuplicates() {
        for (int i = 0; i < shapes.size() - 1; i++) {
            for (int j = i + 1; j < shapes.size(); j++) {
                if (shapes.get(i).equals(shapes.get(j))) {
                    shapes.remove(j);
                }
            }
        }
    }
}
