public class Square extends Rectangle {
    /**
     * NTKong.
     */
    public Square() {
    }

    /**
     * NTKong.
     */
    public Square(double side) {
        this.setSide(side);
    }

    /**
     * NTKong.
     */
    public Square(double side, String color, boolean filled) {
        super(side, side, color, filled);
    }

    /**
     * NTKong.
     */
    public Square(Point point, double side, String color, boolean filled) {
        super(point, side, side, color, filled);
    }

    public double getSide() {
        return super.getWidth();
    }

    public void setSide(double side) {
        super.setLength(side);
        super.setWidth(side);
    }

    @Override
    public void setWidth(double width) {
        super.setWidth(width);
        super.setLength(width);
    }

    @Override
    public void setLength(double length) {
        super.setLength(length);
        super.setWidth(length);
    }

    @Override
    public String toString() {
        String format = "Square[topLeft=%s,side=%s,color=%s,filled=%s]";
        return String.format(format, getTopLeft(), getSide(), getColor(), isFilled());
    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o);
    }
}
