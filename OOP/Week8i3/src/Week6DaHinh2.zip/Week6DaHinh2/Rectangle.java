import java.util.Objects;

public class Rectangle extends Shape {
    protected Point topLeft;
    protected double width;
    protected double length;

    /**
     * NTKong.
     */
    public Rectangle() {
    }

    /**
     * NTKong.
     */
    public Rectangle(double width, double length) {
        super();
        this.setWidth(width);
        this.setLength(length);
    }

    /**
     * NTKong.
     */
    public Rectangle(double width, double length, String color, boolean filled) {
        super(color, filled);
        this.setLength(length);
        this.setWidth(width);
    }

    /**
     * NTKong.
     */
    public Rectangle(Point point, double width, double length, String color, boolean filled) {
        super(color, filled);
        this.setTopLeft(point);
        this.setLength(length);
        this.setWidth(width);
    }

    public double getWidth() {
        return width;
    }

    public void setWidth(double width) {
        this.width = width;
    }

    public double getLength() {
        return length;
    }

    public void setLength(double length) {
        this.length = length;
    }

    @Override
    public double getArea() {
        return getWidth() * getLength();
    }

    @Override
    public double getPerimeter() {
        return (getWidth() + getLength()) * 2.0;
    }

    public Point getTopLeft() {
        return topLeft;
    }

    public void setTopLeft(Point point) {
        this.topLeft = point;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Rectangle)) {
            return false;
        }
        Rectangle rectangle = (Rectangle) o;
        return Double.compare(rectangle.width, width) == 0
                && Double.compare(rectangle.length, length) == 0
                && Objects.equals(topLeft, rectangle.topLeft);
    }

    @Override
    public int hashCode() {
        return Objects.hash(topLeft, width, length);
    }

    @Override
    public String toString() {
        String format = "Rectangle[topLeft=%s,width=%s,length=%s,color=%s,filled=%s]";
        return String.format(format, getTopLeft(), getWidth(), getLength(), getColor(), isFilled());
    }
}
