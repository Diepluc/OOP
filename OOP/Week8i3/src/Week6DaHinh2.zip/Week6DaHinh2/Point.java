import java.util.Objects;

public class Point {
    private double pointX;
    private double pointY;

    public Point(double pointX, double pointY) {
        setPointX(pointX);
        setPointY(pointY);
    }

    public void setPointX(double pointX) {
        this.pointX = pointX;
    }

    public void setPointY(double pointY) {
        this.pointY = pointY;
    }

    public double getPointX() {
        return pointX;
    }

    public double getPointY() {
        return pointY;
    }

    /**
     * NTKong.
     */
    public double distance(Point other) {
        double distanceX = this.getPointX() - other.getPointX();
        double distanceY = this.getPointY() - other.getPointY();
        return Math.sqrt(distanceX * distanceX + distanceY * distanceY);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) {
            return true;
        }
        if (!(o instanceof Point)) {
            return false;
        }
        Point p = (Point) o;
        return Double.compare(p.pointX, pointX) == 0
                && Double.compare(p.pointY, pointY) == 0;
    }

    @Override
    public int hashCode() {
        return Objects.hash(pointX, pointY);
    }

    @Override
    public String toString() {
        return "(" + getPointX() + "," + getPointY() + ")";
    }
}
