public interface GeometricObject {
    double getArea();

    double getPerimeter();

    String getInfo();
}
